# ============================================================
# main.py — AutoWindow Optimizer Bot (Entry Point)
# ============================================================
#
# วิธีรัน:
#   python main.py
#
# วิธีหยุด:
#   Ctrl + C
#
# ต้องการ library:
#   pip install psutil pywinctl keyboard
#   pip install pywin32   (สำหรับ Windows API)
#
# ต้องรันด้วยสิทธิ์ Administrator สำหรับ process management
# ============================================================

import time
import json
import os
import sys

# ── เพิ่ม path ให้ import module ได้ ──────────────────────
sys.path.insert(0, os.path.dirname(__file__))

from utils.logger          import logger
from core.monitor          import get_all_stats, print_stats_report
from core.decision         import decide_mode
from core.process_manager  import kill_bloatware, boost_foreground_process
from core.memory_cleaner   import run_cleanup
from core.window_manager   import apply_window_rules

# ── โหลด Config ──────────────────────────────────────────
CONFIG_PATH = os.path.join(os.path.dirname(__file__), "config", "settings.json")

def load_config() -> dict:
    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        return json.load(f)

# ── Main Loop ────────────────────────────────────────────
def run():
    logger.info("🚀 AutoWindow Optimizer started!")
    logger.info("   Press Ctrl+C to stop\n")

    config       = load_config()
    interval     = config.get("scan_interval_seconds", 5)
    last_mode    = None
    cycle        = 0

    while True:
        try:
            cycle += 1
            logger.info(f"\n── Cycle #{cycle} ──────────────────────────")

            # 1. สแกนสถานะระบบ
            stats = get_all_stats()
            print_stats_report(stats)

            # 2. ตัดสินใจ mode
            mode    = decide_mode(stats, config)
            profile = config["profiles"][mode]

            # 3. ถ้า mode เปลี่ยน → แจ้งเตือน
            if mode != last_mode:
                logger.info(f"🔄 Mode changed: {last_mode} → {mode}")
                last_mode = mode

            # 4. จัด Window Layout
            logger.info("🪟 Applying window rules...")
            apply_window_rules(config.get("window_rules", {}))

            # 5. Kill Bloatware (ถ้า mode ต้องการ)
            if profile.get("kill_bloatware"):
                logger.info("🗑️  Killing bloatware...")
                kill_bloatware(config.get("bloatware_list", []))

            # 6. Boost Priority
            if profile.get("boost_priority"):
                boost_foreground_process()

            # 7. Cleanup RAM / DNS
            run_cleanup(mode, profile)

            # 8. รอรอบหน้า
            logger.info(f"💤 Sleeping {interval}s...\n")
            time.sleep(interval)

        except KeyboardInterrupt:
            logger.info("\n🛑 Stopped by user. Goodbye!")
            break
        except Exception as e:
            logger.error(f"❌ Unexpected error: {e}")
            time.sleep(interval)

if __name__ == "__main__":
    run()
