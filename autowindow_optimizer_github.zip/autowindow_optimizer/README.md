# 🤖 AutoWindow Optimizer

![Python](https://img.shields.io/badge/Python-3.10%2B-blue)
![Platform](https://img.shields.io/badge/Platform-Windows-lightgrey)
![License](https://img.shields.io/badge/License-MIT-green)

> A Python background daemon that automatically manages window layouts and optimizes your Windows system in real-time — no manual effort needed.

---

## ✨ Features

- 🪟 **Auto Window Layout** — Automatically tile/snap windows based on custom rules
- 🎮 **Game Mode** — Detects games and instantly boosts performance
- 🔋 **Battery Mode** — Saves power automatically when battery drops below 30%
- ⚡ **Performance Mode** — Kills bloatware + boosts active process priority
- 🧹 **RAM & Temp Cleaner** — Automatically cleans RAM and junk files
- 📡 **DNS Flush** — Clears DNS cache to reduce in-game ping
- 🛡️ **Safety Whitelist** — Prevents killing critical Windows processes
- 📊 **Real-time Logging** — Logs every action for full transparency

---

---

## 📁 Project Structure

```
autowindow_optimizer/
├── main.py                  ← Entry point (run this)
├── requirements.txt         ← Required libraries
├── core/
│   ├── monitor.py           ← Scans CPU/RAM/Battery/Processes
│   ├── decision.py          ← Decides which Mode to activate
│   ├── window_manager.py    ← Handles Window Layout (pywinctl)
│   ├── process_manager.py   ← Kills bloatware / sets priority
│   └── memory_cleaner.py    ← Cleans RAM, temp files, DNS
├── config/
│   └── settings.json        ← All configuration lives here
├── utils/
│   ├── logger.py            ← Logs all actions
│   └── safeguard.py         ← Protected process whitelist
└── logs/                    ← Log files stored here
```

---

## 🚀 Getting Started

### Step 1: Install Python
Download Python 3.10+ from https://python.org

### Step 2: Install dependencies
```bash
pip install -r requirements.txt
```

### Step 3: Configure settings
Open `config/settings.json` and edit:
- `window_rules` → add your frequently used apps + desired positions
- `bloatware_list` → add apps you don't want running in the background
- `game_process_list` → add your game executable names

### Step 4: Run the bot
**Must run as Administrator:**
```bash
python main.py
```
Right-click CMD → "Run as administrator", then run the command above.

### Step 5: Stop the bot
```
Ctrl + C
```

---

## ⚙️ Window Rules Configuration

Edit the `window_rules` section in `config/settings.json`:

```json
"window_rules": {
    "chrome.exe":   { "monitor": 0, "tile": "left-half" },
    "Code.exe":     { "monitor": 0, "tile": "right-half" },
    "Discord.exe":  { "monitor": 1, "tile": "top-half" }
}
```

### Supported Tile Options

| Tile Name      | Position                  |
|----------------|---------------------------|
| `left-half`    | Left half of screen       |
| `right-half`   | Right half of screen      |
| `top-half`     | Top half of screen        |
| `bottom-half`  | Bottom half of screen     |
| `fullscreen`   | Full screen               |
| `center`       | Centered (75% of screen)  |
| `top-left`     | Top-left quarter          |
| `top-right`    | Top-right quarter         |
| `bottom-left`  | Bottom-left quarter       |
| `bottom-right` | Bottom-right quarter      |

---

## 🔄 3 Operating Modes

| Mode            | Trigger                              | Actions                                      |
|-----------------|--------------------------------------|----------------------------------------------|
| 🎮 GAME         | Game process detected                | Kill all non-essential + boost priority + flush DNS |
| 🔋 BATTERY      | Battery < 30% and unplugged         | Kill bloatware + clean RAM                   |
| ⚡ PERFORMANCE   | Normal / high CPU or RAM usage       | Arrange windows + boost priority             |

---

## ⚠️ Important Warnings

1. **Always run as Administrator** — process management won't work otherwise
2. **Do not modify `SYSTEM_WHITELIST`** in `safeguard.py` — these are real Windows system processes
3. **Review `bloatware_list` carefully** — never add processes you actually need
4. **Test in monitor-only mode first** — check logs before enabling kill actions

---

## 📊 Viewing Logs

Logs are saved to `logs/optimizer_YYYYMMDD.log` and also printed to the console in real-time.

---

## 🗺️ Roadmap

- [x] Phase 1: Monitor + Logging
- [x] Phase 2: Window Manager
- [x] Phase 3: Process Manager
- [ ] Phase 4: System Tray (pystray)
- [ ] Phase 5: Game Mode Network Optimizer
- [ ] Phase 6: Windows Service (auto-start on boot)
- [ ] Phase 7: GUI Dashboard

---

## 🤝 Credits

Architecture inspired by ideas from: Claude + Grok + ChatGPT + Gemini + Perplexity

---

## 📄 License

MIT License — Free to use and modify.
