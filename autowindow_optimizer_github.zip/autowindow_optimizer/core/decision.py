# ============================================================
# decision.py — ตัดสินใจว่าจะใช้ Mode ไหน (Brain ของระบบ)
# ============================================================
# Logic:
#   1. ถ้าเกมรันอยู่         → GAME mode
#   2. ถ้าแบตต่ำกว่า 30%    → BATTERY mode
#   3. ถ้า CPU/RAM สูงมาก   → PERFORMANCE mode (aggressive)
#   4. ปกติ                 → PERFORMANCE mode (normal)
# ============================================================

from utils.logger import logger

def decide_mode(stats: dict, config: dict) -> str:
    """
    รับ stats จาก monitor.py และ config จาก settings.json
    คืนค่า: "GAME" | "BATTERY" | "PERFORMANCE"
    """
    game_list   = config.get("game_process_list", [])
    bat_thresh  = config.get("battery_threshold", 30)
    cpu_thresh  = config.get("cpu_threshold_percent", 90)
    ram_thresh  = config.get("ram_threshold_percent", 85)

    battery     = stats["battery"]
    cpu         = stats["cpu"]
    ram_percent = stats["ram"]["percent"]

    # Priority 1: Game Mode
    from core.monitor import is_game_running
    if is_game_running(game_list):
        logger.info("🎮 GAME MODE — game process detected")
        return "GAME"

    # Priority 2: Battery Mode
    if battery["available"] and not battery["plugged"] and battery["percent"] < bat_thresh:
        logger.info(f"🔋 BATTERY MODE — battery at {battery['percent']}%")
        return "BATTERY"

    # Priority 3: Performance Mode (system under stress)
    if cpu > cpu_thresh or ram_percent > ram_thresh:
        logger.info(f"⚡ PERFORMANCE MODE — CPU: {cpu}%  RAM: {ram_percent}%")
        return "PERFORMANCE"

    # Default
    logger.info(f"✅ PERFORMANCE MODE (normal) — CPU: {cpu}%  RAM: {ram_percent}%")
    return "PERFORMANCE"
