# ============================================================
# process_manager.py — จัดการ Process (kill/priority)
# ============================================================
# ทำหน้าที่:
#   - Kill bloatware ที่กำหนดใน config
#   - เพิ่ม Priority ให้ process ที่ active อยู่
#   - ปลอดภัย 100% เพราะเช็ค whitelist ก่อนทุกครั้ง
# ============================================================

import psutil
from utils.safeguard import is_safe_to_kill, is_safe_to_modify
from utils.logger import logger

def kill_bloatware(bloatware_list: list):
    """Kill process ที่อยู่ใน bloatware list"""
    killed = []
    for proc in psutil.process_iter(["pid", "name"]):
        try:
            name = proc.info["name"]
            if name in bloatware_list and is_safe_to_kill(name):
                proc.kill()
                killed.append(name)
                logger.info(f"🗑️  Killed bloatware: {name}")
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass
    if not killed:
        logger.info("✅ No bloatware found to kill")
    return killed

def boost_foreground_process():
    """เพิ่ม Priority ให้ foreground process (Windows only)"""
    try:
        import win32process, win32con, win32gui
        hwnd = win32gui.GetForegroundWindow()
        if hwnd:
            _, pid = win32process.GetWindowThreadProcessId(hwnd)
            proc = psutil.Process(pid)
            name = proc.name()
            if is_safe_to_modify(name):
                proc.nice(psutil.HIGH_PRIORITY_CLASS)
                logger.info(f"⚡ Boosted priority: {name} (PID {pid})")
    except ImportError:
        logger.warning("⚠️  win32process not available — skipping priority boost")
    except Exception as e:
        logger.warning(f"⚠️  Could not boost priority: {e}")

def reset_all_priorities():
    """Reset priority ทุก process กลับปกติ"""
    for proc in psutil.process_iter(["pid", "name"]):
        try:
            name = proc.info["name"]
            if is_safe_to_modify(name):
                proc.nice(psutil.NORMAL_PRIORITY_CLASS)
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass
    logger.info("🔄 Reset all process priorities to normal")

def get_heavy_processes(threshold_ram: float = 5.0) -> list:
    """ดึง process ที่กิน RAM เกิน threshold (%)"""
    heavy = []
    for proc in psutil.process_iter(["pid", "name", "memory_percent"]):
        try:
            if proc.info["memory_percent"] > threshold_ram:
                heavy.append(proc.info)
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass
    return heavy
