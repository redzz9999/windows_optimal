# ============================================================
# memory_cleaner.py — ล้าง RAM และไฟล์ขยะ
# ============================================================
# ทำหน้าที่:
#   - Trim RAM ด้วย ctypes (Windows API)
#   - ลบไฟล์ใน %TEMP%
#   - ล้าง Prefetch cache
# ============================================================

import os
import shutil
import ctypes
from utils.logger import logger

def trim_ram():
    """
    สั่ง Windows คืน RAM ที่ process ไม่ได้ใช้แล้ว
    ใช้ EmptyWorkingSet ผ่าน ctypes
    """
    try:
        import psutil
        for proc in psutil.process_iter(["pid", "name"]):
            try:
                handle = ctypes.windll.kernel32.OpenProcess(0x1F0FFF, False, proc.info["pid"])
                if handle:
                    ctypes.windll.psapi.EmptyWorkingSet(handle)
                    ctypes.windll.kernel32.CloseHandle(handle)
            except Exception:
                pass
        logger.info("🧹 RAM trimmed successfully")
    except Exception as e:
        logger.warning(f"⚠️  RAM trim failed: {e}")

def clean_temp_files():
    """ลบไฟล์ขยะใน %TEMP%"""
    temp_dir = os.getenv("TEMP", "")
    if not temp_dir or not os.path.exists(temp_dir):
        logger.warning("⚠️  TEMP directory not found")
        return

    deleted = 0
    failed  = 0
    for item in os.listdir(temp_dir):
        item_path = os.path.join(temp_dir, item)
        try:
            if os.path.isfile(item_path):
                os.remove(item_path)
                deleted += 1
            elif os.path.isdir(item_path):
                shutil.rmtree(item_path, ignore_errors=True)
                deleted += 1
        except Exception:
            failed += 1

    logger.info(f"🗑️  Temp cleanup: {deleted} deleted, {failed} skipped")

def flush_dns():
    """Flush DNS cache — ช่วยลด ping"""
    try:
        os.system("ipconfig /flushdns >nul 2>&1")
        logger.info("📡 DNS cache flushed")
    except Exception as e:
        logger.warning(f"⚠️  DNS flush failed: {e}")

def run_cleanup(mode: str, profile: dict):
    """รัน cleanup ตาม mode ที่เลือก"""
    if profile.get("clean_ram"):
        trim_ram()
        clean_temp_files()
    if profile.get("flush_dns"):
        flush_dns()
