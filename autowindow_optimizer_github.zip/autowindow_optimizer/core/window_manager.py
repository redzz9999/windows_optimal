# ============================================================
# window_manager.py — จัด Window Layout อัตโนมัติ
# ============================================================
# ทำหน้าที่:
#   - ตรวจ window ที่เปิดอยู่
#   - จัดตำแหน่งตาม rules ใน settings.json
#   - รองรับ tile: left-half, right-half, top-half,
#                  bottom-half, fullscreen, center
# ============================================================

from utils.logger import logger

def get_screen_size():
    """ดูขนาดหน้าจอหลัก"""
    try:
        import ctypes
        user32 = ctypes.windll.user32
        return user32.GetSystemMetrics(0), user32.GetSystemMetrics(1)
    except Exception:
        return 1920, 1080  # fallback

def get_tile_geometry(tile: str, monitor_index: int = 0):
    """
    คำนวณ x, y, width, height จาก tile name
    รองรับ: left-half, right-half, top-half, bottom-half,
             fullscreen, center, top-left, top-right,
             bottom-left, bottom-right
    """
    w, h = get_screen_size()

    tiles = {
        "left-half":    (0,       0,      w//2,   h),
        "right-half":   (w//2,    0,      w//2,   h),
        "top-half":     (0,       0,      w,      h//2),
        "bottom-half":  (0,       h//2,   w,      h//2),
        "fullscreen":   (0,       0,      w,      h),
        "center":       (w//4,    h//8,   w//2,   int(h*0.75)),
        "top-left":     (0,       0,      w//2,   h//2),
        "top-right":    (w//2,    0,      w//2,   h//2),
        "bottom-left":  (0,       h//2,   w//2,   h//2),
        "bottom-right": (w//2,    h//2,   w//2,   h//2),
    }
    return tiles.get(tile, (0, 0, w//2, h))

def apply_window_rules(window_rules: dict):
    """
    วนดู window ที่เปิดอยู่ทั้งหมด
    ถ้าตรงกับ rule ใน config → จัดตำแหน่ง
    """
    try:
        import pywinctl as pwc
    except ImportError:
        logger.warning("⚠️  pywinctl not installed — run: pip install pywinctl")
        return

    for exe_name, rule in window_rules.items():
        tile  = rule.get("tile", "left-half")
        x, y, w, h = get_tile_geometry(tile)

        # หา window ที่ process ชื่อตรงกัน
        all_windows = pwc.getAllWindows()
        for win in all_windows:
            try:
                if not win.title:
                    continue
                # ตรวจจาก title (pywinctl ไม่ได้ expose exe โดยตรง)
                win_title = win.title.lower()
                app_name  = exe_name.replace(".exe", "").lower()
                if app_name in win_title:
                    win.moveTo(x, y)
                    win.resizeTo(w, h)
                    logger.info(f"🪟 Arranged '{win.title}' → {tile} ({x},{y} {w}x{h})")
            except Exception as e:
                logger.warning(f"⚠️  Could not arrange window: {e}")

def maintain_single_window(title: str, x: int, y: int, w: int, h: int):
    """
    Lock window เดียวให้อยู่ตำแหน่งที่กำหนดตลอดเวลา
    (จาก Perplexity skeleton)
    """
    try:
        import pywinctl as pwc
        windows = pwc.getWindowsWithTitle(title)
        if windows:
            win = windows[0]
            if win.left != x or win.top != y or win.width != w or win.height != h:
                win.moveTo(x, y)
                win.resizeTo(w, h)
                win.activate()
                logger.info(f"🪟 Corrected window: '{title}'")
    except ImportError:
        logger.warning("⚠️  pywinctl not installed")
    except Exception as e:
        logger.warning(f"⚠️  maintain_single_window error: {e}")
