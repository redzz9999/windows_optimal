# ============================================================
# monitor.py — ตรวจสอบสถานะระบบแบบ Real-time (Phase 1)
# ============================================================
# ทำหน้าที่: สแกน CPU / RAM / Battery / Process ทุก X วินาที
# แล้วส่งข้อมูลให้ decision.py ตัดสินใจว่าจะทำอะไรต่อ
# ============================================================

import psutil
import platform

def get_cpu_usage() -> float:
    """ดู % การใช้ CPU ตอนนี้"""
    return psutil.cpu_percent(interval=1)

def get_ram_usage() -> dict:
    """ดูการใช้ RAM — คืนค่า total, used, percent"""
    ram = psutil.virtual_memory()
    return {
        "total_gb": round(ram.total / 1e9, 1),
        "used_gb":  round(ram.used  / 1e9, 1),
        "percent":  ram.percent
    }

def get_battery() -> dict:
    """ดูสถานะแบต — ถ้าเป็น Desktop จะคืน None"""
    battery = psutil.sensors_battery()
    if battery is None:
        return {"percent": 100, "plugged": True, "available": False}
    return {
        "percent":   round(battery.percent, 1),
        "plugged":   battery.power_plugged,
        "available": True
    }

def get_running_processes() -> list:
    """ดึงรายชื่อ process ที่รันอยู่ทั้งหมด"""
    processes = []
    for proc in psutil.process_iter(["pid", "name", "cpu_percent", "memory_percent"]):
        try:
            processes.append({
                "pid":    proc.info["pid"],
                "name":   proc.info["name"],
                "cpu":    proc.info["cpu_percent"],
                "memory": round(proc.info["memory_percent"], 2)
            })
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass
    return processes

def get_top_processes(n: int = 5) -> list:
    """ดึง top N process ที่กิน RAM มากสุด"""
    procs = get_running_processes()
    return sorted(procs, key=lambda x: x["memory"], reverse=True)[:n]

def get_all_stats() -> dict:
    """รวมทุกอย่างเป็น snapshot เดียว — ใช้ใน main loop"""
    return {
        "cpu":       get_cpu_usage(),
        "ram":       get_ram_usage(),
        "battery":   get_battery(),
        "processes": get_running_processes()
    }

def is_game_running(game_list: list) -> bool:
    """ตรวจว่ามีเกมรันอยู่ไหม"""
    running = {p["name"].lower() for p in get_running_processes()}
    return any(g.lower() in running for g in game_list)

def print_stats_report(stats: dict):
    """พิมพ์รายงานสถานะให้ดูง่ายๆ"""
    print("\n" + "="*50)
    print(f"  💻 CPU Usage  : {stats['cpu']}%")
    print(f"  🧠 RAM Usage  : {stats['ram']['used_gb']} / {stats['ram']['total_gb']} GB  ({stats['ram']['percent']}%)")
    bat = stats["battery"]
    if bat["available"]:
        plug = "🔌 Plugged" if bat["plugged"] else "🔋 On Battery"
        print(f"  🔋 Battery    : {bat['percent']}%  {plug}")
    else:
        print(f"  🖥️  Desktop    : No battery")
    print("\n  📊 Top 5 Processes (RAM):")
    for p in sorted(stats["processes"], key=lambda x: x["memory"], reverse=True)[:5]:
        print(f"     {p['name']:<35} RAM: {p['memory']}%")
    print("="*50)
