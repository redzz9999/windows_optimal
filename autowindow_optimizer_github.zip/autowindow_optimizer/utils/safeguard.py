# ============================================================
# safeguard.py — ป้องกันการแตะ process สำคัญของ Windows
# ============================================================

# ❌ ห้าม kill เด็ดขาด — ถ้า kill จะ BSOD หรือ Windows พัง
SYSTEM_WHITELIST = [
    "explorer.exe",
    "winlogon.exe",
    "csrss.exe",
    "lsass.exe",
    "wininit.exe",
    "services.exe",
    "svchost.exe",
    "system",
    "registry",
    "smss.exe",
    "dwm.exe",
    "taskmgr.exe",
    "python.exe",      # ป้องกัน script kill ตัวเอง
    "pythonw.exe",
]

def is_safe_to_kill(process_name: str) -> bool:
    """ตรวจสอบว่า process นี้ปลอดภัยที่จะ kill ไหม"""
    return process_name.lower() not in [p.lower() for p in SYSTEM_WHITELIST]

def is_safe_to_modify(process_name: str) -> bool:
    """ตรวจสอบว่า process นี้ปลอดภัยที่จะแก้ priority ไหม"""
    critical = ["lsass.exe", "csrss.exe", "wininit.exe", "smss.exe"]
    return process_name.lower() not in critical
